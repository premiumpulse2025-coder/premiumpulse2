
Premium Pulse - BTech Final Project

Files Included:
1. raw_insurance_dataset.csv
   - Original dataset
   - Not normalized
   - Not preprocessed
   - Contains categorical + numerical features

2. train_model.py
   - Shows complete ML pipeline
   - Encoding categorical data
   - Train-test split
   - Model training (Linear Regression)
   - Evaluation metrics

How to Run:
1. Install requirements:
   pip install pandas scikit-learn

2. Run:
   python train_model.py
